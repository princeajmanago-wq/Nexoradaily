package com.nexora.daily;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickCallback;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** The /daily dialog windows. */
public class DailyDialog {

    private final NexoraDaily plugin;
    private final DailyManager mgr;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public DailyDialog(NexoraDaily plugin, DailyManager mgr) {
        this.plugin = plugin;
        this.mgr = mgr;
    }

    // ---------- helpers ----------

    private ClickCallback.Options options() {
        return ClickCallback.Options.builder().uses(1).lifetime(Duration.ofMinutes(15)).build();
    }

    /** A dialog button that runs code on the main thread when clicked. */
    private DialogAction click(Runnable r) {
        return DialogAction.customClick(
                (view, audience) -> Bukkit.getScheduler().runTask(plugin, r),
                options());
    }

    private ActionButton button(String label, String tooltip, int width, DialogAction action) {
        return ActionButton.create(
                mm.deserialize(label),
                tooltip == null ? null : mm.deserialize(tooltip),
                width,
                action);
    }

    private DialogBody text(String minimessage) {
        return DialogBody.plainMessage(mm.deserialize(minimessage));
    }

    private void show(Player p, Component title, List<DialogBody> body, List<ActionButton> buttons) {
        Dialog dialog = Dialog.create(factory -> factory.empty()
                .base(DialogBase.builder(title).canCloseWithEscape(true).body(body).build())
                .type(DialogType.multiAction(buttons).build()));
        p.showDialog(dialog);
    }

    private String esc(String s) {
        return mm.escapeTags(s);
    }

    // ---------- main window ----------

    public void openMain(Player p) {
        UUID id = p.getUniqueId();
        int days = mgr.days();
        int day = mgr.nextDay(id);
        boolean can = !mgr.claimedToday(id);

        StringBuilder sb = new StringBuilder();
        sb.append("<gold><bold>Day ").append(day).append("</bold></gold> <gray>of ").append(days).append("</gray><newline>");
        if (day == days) {
            sb.append("<light_purple><bold>\u2605 JACKPOT DAY \u2605</bold></light_purple><newline>");
        }
        String name = mgr.rewardName(day);
        if (!name.isBlank()) sb.append("<aqua>").append(esc(name)).append("</aqua><newline>");
        sb.append("<newline><gray>Today's reward:</gray><newline>");
        for (String l : mgr.rewardLines(day)) {
            sb.append("<yellow> \u2022 </yellow><white>").append(esc(l)).append("</white><newline>");
        }
        sb.append("<newline>");
        if (can) {
            sb.append("<green>Ready to claim!</green>");
        } else {
            sb.append("<red>You already claimed today.</red><newline><gray>Next reward in </gray><white>")
                    .append(mgr.timeLeft()).append("</white>");
        }

        List<DialogBody> body = new ArrayList<>();
        body.add(text(sb.toString()));

        List<ActionButton> buttons = new ArrayList<>();
        if (can) {
            buttons.add(button("<green><bold>Claim Day " + day + "</bold></green>",
                    "Click to claim today's reward", 200,
                    click(() -> claimNow(p))));
        }
        buttons.add(button("<yellow>All Rewards</yellow>", "See every day", 200,
                click(() -> openRewards(p))));
        buttons.add(button("<gray>Close</gray>", null, 200, null));

        show(p, mm.deserialize("<gold><bold>Daily Rewards</bold></gold>"), body, buttons);
    }

    private void claimNow(Player p) {
        if (!p.isOnline()) return;
        DailyManager.ClaimResult r = mgr.claim(p);
        if (r.ok()) {
            plugin.celebrate(p, r.day());
            openClaimed(p, r);
        } else {
            openMain(p);
        }
    }

    // ---------- "you claimed it" window ----------

    public void openClaimed(Player p, DailyManager.ClaimResult r) {
        int days = mgr.days();
        StringBuilder sb = new StringBuilder();
        sb.append("<green><bold>You claimed Day ").append(r.day()).append("!</bold></green><newline><newline>");
        for (String l : r.lines()) {
            sb.append("<yellow> \u2022 </yellow><white>").append(esc(l)).append("</white><newline>");
        }
        sb.append("<newline>");
        if (r.day() >= days) {
            sb.append("<light_purple>You finished all ").append(days)
                    .append(" days! The cycle starts again tomorrow.</light_purple>");
        } else {
            int next = r.day() + 1;
            sb.append("<gray>Come back tomorrow for </gray><gold>Day ").append(next).append("</gold>");
            String nn = mgr.rewardName(next);
            if (!nn.isBlank()) sb.append("<gray>: </gray><aqua>").append(esc(nn)).append("</aqua>");
        }

        List<DialogBody> body = new ArrayList<>();
        body.add(text(sb.toString()));

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(button("<green>Awesome!</green>", null, 200, null));
        buttons.add(button("<yellow>All Rewards</yellow>", null, 200, click(() -> openRewards(p))));

        show(p, mm.deserialize("<green><bold>Reward Claimed!</bold></green>"), body, buttons);
    }

    // ---------- list of all days ----------

    public void openRewards(Player p) {
        int days = mgr.days();
        int current = mgr.nextDay(p.getUniqueId());
        boolean claimed = mgr.claimedToday(p.getUniqueId());

        List<DialogBody> body = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (int d = 1; d <= days; d++) {
            String label = mgr.rewardName(d);
            if (label.isBlank()) {
                List<String> lines = mgr.rewardLines(d);
                label = lines.isEmpty() ? "-" : String.join(", ", lines.subList(0, Math.min(2, lines.size())));
            }
            boolean done = d < current;
            String prefix;
            if (d == current && !claimed) {
                prefix = "<green><bold>\u25B6 Day " + d + "</bold></green>";
            } else if (done) {
                prefix = "<dark_gray>\u2714 Day " + d + "</dark_gray>";
            } else if (d == days) {
                prefix = "<light_purple><bold>\u2605 Day " + d + "</bold></light_purple>";
            } else {
                prefix = "<gray>Day " + d + "</gray>";
            }
            sb.append(prefix).append("<gray>: </gray><white>").append(esc(label)).append("</white><newline>");

            if (d % 10 == 0 || d == days) {
                body.add(text(sb.toString()));
                sb.setLength(0);
            }
        }

        List<ActionButton> buttons = new ArrayList<>();
        buttons.add(button("<yellow>Back</yellow>", null, 200, click(() -> openMain(p))));
        buttons.add(button("<gray>Close</gray>", null, 200, null));

        show(p, mm.deserialize("<gold><bold>All Daily Rewards</bold></gold>"), body, buttons);
    }
}
