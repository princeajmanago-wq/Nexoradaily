package com.nexora.daily;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Stores who claimed what and hands out the rewards. */
public class DailyManager {

    public record ClaimResult(boolean ok, int day, List<String> lines) {
    }

    private final NexoraDaily plugin;
    private File file;
    private YamlConfiguration data;

    public DailyManager(NexoraDaily plugin) {
        this.plugin = plugin;
    }

    public void load() {
        file = new File(plugin.getDataFolder(), "players.yml");
        data = YamlConfiguration.loadConfiguration(file);
    }

    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save players.yml: " + e.getMessage());
        }
    }

    // ---------- time ----------

    public int days() {
        return Math.max(1, plugin.getConfig().getInt("days", 30));
    }

    public ZoneId zone() {
        String z = plugin.getConfig().getString("timezone", "");
        if (z == null || z.isBlank()) return ZoneId.systemDefault();
        try {
            return ZoneId.of(z.trim());
        } catch (Exception e) {
            return ZoneId.systemDefault();
        }
    }

    public LocalDate today() {
        return LocalDate.now(zone());
    }

    /** Text like "5h 12m" until the next reward is available. */
    public String timeLeft() {
        ZonedDateTime now = ZonedDateTime.now(zone());
        ZonedDateTime next = today().plusDays(1).atStartOfDay(zone());
        Duration d = Duration.between(now, next);
        return d.toHours() + "h " + d.toMinutesPart() + "m";
    }

    // ---------- player state ----------

    public boolean claimedToday(UUID id) {
        String last = data.getString("players." + id + ".last");
        return last != null && last.equals(today().toString());
    }

    /** The day number this player will claim next (1..days). */
    public int nextDay(UUID id) {
        String path = "players." + id;
        int day = data.getInt(path + ".day", 1);
        String last = data.getString(path + ".last");
        if (last != null && plugin.getConfig().getBoolean("reset-on-miss", false)) {
            try {
                LocalDate l = LocalDate.parse(last);
                if (l.isBefore(today().minusDays(1))) day = 1;
            } catch (Exception ignored) {
                // bad date in the file: ignore it
            }
        }
        if (day < 1 || day > days()) day = 1;
        return day;
    }

    public ClaimResult claim(Player p) {
        UUID id = p.getUniqueId();
        if (claimedToday(id)) return new ClaimResult(false, nextDay(id), List.of());

        int day = nextDay(id);
        List<String> lines = giveReward(p, day);

        int next = day + 1;
        if (next > days()) next = 1; // after the last day the cycle starts again

        String path = "players." + id;
        data.set(path + ".name", p.getName());
        data.set(path + ".day", next);
        data.set(path + ".last", today().toString());
        save();
        return new ClaimResult(true, day, lines);
    }

    public void resetPlayer(UUID id) {
        data.set("players." + id, null);
        save();
    }

    public void setDay(UUID id, String name, int day) {
        data.set("players." + id + ".name", name);
        data.set("players." + id + ".day", Math.max(1, Math.min(days(), day)));
        data.set("players." + id + ".last", null);
        save();
    }

    // ---------- rewards ----------

    public String rewardName(int day) {
        return plugin.getConfig().getString("rewards." + day + ".name", "");
    }

    /** Readable lines like "16x Bread" for the dialog. */
    public List<String> rewardLines(int day) {
        List<String> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("rewards." + day);
        if (sec == null) return out;
        for (String spec : sec.getStringList("items")) {
            String d = describe(spec);
            if (d != null) out.add(d);
        }
        out.addAll(sec.getStringList("display"));
        return out;
    }

    private List<String> giveReward(Player p, int day) {
        List<String> lines = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("rewards." + day);
        if (sec == null) {
            plugin.getLogger().warning("No reward set for day " + day + " in config.yml");
            return lines;
        }

        for (String spec : sec.getStringList("items")) {
            List<ItemStack> stacks = parseItem(spec);
            if (stacks.isEmpty()) continue;
            for (ItemStack it : stacks) {
                Map<Integer, ItemStack> left = p.getInventory().addItem(it);
                for (ItemStack l : left.values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), l); // inventory full: drop at feet
                }
            }
            String d = describe(spec);
            if (d != null) lines.add(d);
        }

        for (String c : sec.getStringList("commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), c.replace("%player%", p.getName()));
        }
        lines.addAll(sec.getStringList("display"));
        return lines;
    }

    /** "MATERIAL:amount" or "MATERIAL:amount:ENCHANT=level,ENCHANT=level". */
    private List<ItemStack> parseItem(String spec) {
        List<ItemStack> out = new ArrayList<>();
        String[] parts = spec.split(":");
        Material m = Material.matchMaterial(parts[0].trim());
        if (m == null || m.isAir() || !m.isItem()) {
            plugin.getLogger().warning("Unknown item in config.yml: " + spec);
            return out;
        }

        int amount = 1;
        if (parts.length > 1) {
            try {
                amount = Math.max(1, Integer.parseInt(parts[1].trim()));
            } catch (NumberFormatException ignored) {
                // keep 1
            }
        }

        Map<Enchantment, Integer> ench = new HashMap<>();
        if (parts.length > 2) {
            for (String e : parts[2].split(",")) {
                String[] kv = e.split("=");
                Enchantment en = Registry.ENCHANTMENT.get(
                        NamespacedKey.minecraft(kv[0].trim().toLowerCase(Locale.ROOT)));
                if (en == null) {
                    plugin.getLogger().warning("Unknown enchantment '" + kv[0] + "' in " + spec);
                    continue;
                }
                int lvl = 1;
                if (kv.length > 1) {
                    try {
                        lvl = Integer.parseInt(kv[1].trim());
                    } catch (NumberFormatException ignored) {
                        // keep 1
                    }
                }
                ench.put(en, lvl);
            }
        }

        int max = Math.max(1, m.getMaxStackSize());
        while (amount > 0) {
            int n = Math.min(amount, max);
            ItemStack it = new ItemStack(m, n);
            if (!ench.isEmpty()) it.addUnsafeEnchantments(ench);
            out.add(it);
            amount -= n;
        }
        return out;
    }

    /** Text for one item entry, or null if the material is invalid. */
    private String describe(String spec) {
        String[] parts = spec.split(":");
        Material m = Material.matchMaterial(parts[0].trim());
        if (m == null || m.isAir() || !m.isItem()) return null;

        int amount = 1;
        if (parts.length > 1) {
            try {
                amount = Math.max(1, Integer.parseInt(parts[1].trim()));
            } catch (NumberFormatException ignored) {
                // keep 1
            }
        }
        StringBuilder name = new StringBuilder();
        for (String w : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) continue;
            if (name.length() > 0) name.append(' ');
            name.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return amount + "x " + name + (parts.length > 2 ? " (enchanted)" : "");
    }
}
