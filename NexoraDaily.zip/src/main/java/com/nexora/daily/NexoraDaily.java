package com.nexora.daily;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Duration;

public class NexoraDaily extends JavaPlugin implements Listener {

    private final MiniMessage mm = MiniMessage.miniMessage();
    private DailyManager manager;
    private DailyDialog dialogs;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        manager = new DailyManager(this);
        manager.load();
        dialogs = new DailyDialog(this, manager);

        DailyCommand cmd = new DailyCommand(this);
        getCommand("daily").setExecutor(cmd);
        getCommand("daily").setTabCompleter(cmd);
        getServer().getPluginManager().registerEvents(this, this);

        getLogger().info("NexoraDaily enabled (" + manager.days() + " days).");
    }

    public DailyManager manager() {
        return manager;
    }

    public DailyDialog dialogs() {
        return dialogs;
    }

    public void reloadAll() {
        reloadConfig();
        manager.load();
    }

    public Component msg(String key, TagResolver... resolvers) {
        String raw = getConfig().getString("messages." + key, key);
        return mm.deserialize(raw, resolvers);
    }

    /** Sound, title and (on the last day) a server-wide broadcast. */
    public void celebrate(Player p, int day) {
        boolean last = day >= manager.days();
        p.playSound(p.getLocation(),
                last ? Sound.UI_TOAST_CHALLENGE_COMPLETE : Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);

        Component title = last
                ? Component.text("DAY " + day + " JACKPOT!", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                : Component.text("DAY " + day + " CLAIMED", NamedTextColor.GOLD, TextDecoration.BOLD);
        Component sub = Component.text(last ? "Legendary reward unlocked!" : "See you tomorrow!", NamedTextColor.GRAY);
        p.showTitle(Title.title(title, sub, Title.Times.times(
                Duration.ofMillis(400), Duration.ofMillis(2500), Duration.ofMillis(800))));

        if (last && getConfig().getBoolean("broadcast-final-day", true)) {
            Bukkit.broadcast(msg("broadcast-final",
                    Placeholder.unparsed("player", p.getName()),
                    Placeholder.unparsed("day", String.valueOf(day))));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (!getConfig().getBoolean("remind-on-join", true)) return;
        Player p = e.getPlayer();
        if (!p.hasPermission("nexoradaily.use")) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && !manager.claimedToday(p.getUniqueId())) {
                p.sendMessage(msg("daily-ready"));
            }
        }, 60L);
    }
}
