package com.nexora.daily;

import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DailyCommand implements CommandExecutor, TabCompleter {

    private final NexoraDaily plugin;

    public DailyCommand(NexoraDaily plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String sub = a.length == 0 ? "open" : a[0].toLowerCase(Locale.ROOT);

        switch (sub) {
            case "open" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(plugin.msg("player-only"));
                    return true;
                }
                if (!p.hasPermission("nexoradaily.use")) {
                    s.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                plugin.dialogs().openMain(p);
            }
            case "rewards" -> {
                if (s instanceof Player p && p.hasPermission("nexoradaily.use")) {
                    plugin.dialogs().openRewards(p);
                } else {
                    s.sendMessage(plugin.msg("no-permission"));
                }
            }
            case "claim" -> {
                // fallback if dialogs are ever unavailable
                if (!(s instanceof Player p) || !p.hasPermission("nexoradaily.use")) {
                    s.sendMessage(plugin.msg("no-permission"));
                    return true;
                }
                DailyManager.ClaimResult r = plugin.manager().claim(p);
                if (r.ok()) {
                    plugin.celebrate(p, r.day());
                    plugin.dialogs().openClaimed(p, r);
                } else {
                    p.sendMessage(plugin.msg("already-claimed",
                            Placeholder.unparsed("time", plugin.manager().timeLeft())));
                }
            }
            case "reset" -> {
                if (!admin(s)) return true;
                if (a.length < 2) {
                    s.sendMessage(plugin.msg("usage"));
                    return true;
                }
                OfflinePlayer t = target(a[1]);
                plugin.manager().resetPlayer(t.getUniqueId());
                s.sendMessage(plugin.msg("reset", Placeholder.unparsed("player", a[1])));
            }
            case "set" -> {
                if (!admin(s)) return true;
                if (a.length < 3) {
                    s.sendMessage(plugin.msg("usage"));
                    return true;
                }
                int day;
                try {
                    day = Integer.parseInt(a[2]);
                } catch (NumberFormatException e) {
                    s.sendMessage(plugin.msg("usage"));
                    return true;
                }
                OfflinePlayer t = target(a[1]);
                plugin.manager().setDay(t.getUniqueId(), a[1], day);
                s.sendMessage(plugin.msg("set",
                        Placeholder.unparsed("player", a[1]),
                        Placeholder.unparsed("day", String.valueOf(day))));
            }
            case "reload" -> {
                if (!admin(s)) return true;
                plugin.reloadAll();
                s.sendMessage(plugin.msg("reloaded"));
            }
            default -> s.sendMessage(plugin.msg("usage"));
        }
        return true;
    }

    private boolean admin(CommandSender s) {
        if (s.hasPermission("nexoradaily.admin")) return true;
        s.sendMessage(plugin.msg("no-permission"));
        return false;
    }

    private OfflinePlayer target(String name) {
        Player online = Bukkit.getPlayerExact(name);
        return online != null ? online : Bukkit.getOfflinePlayer(name);
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(List.of("open", "rewards", "claim"));
            if (s.hasPermission("nexoradaily.admin")) subs.addAll(List.of("reset", "set", "reload"));
            for (String o : subs) if (o.startsWith(a[0].toLowerCase(Locale.ROOT))) out.add(o);
        } else if (a.length == 2 && s.hasPermission("nexoradaily.admin")
                && (a[0].equalsIgnoreCase("reset") || a[0].equalsIgnoreCase("set"))) {
            for (Player p : Bukkit.getOnlinePlayers())
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(a[1].toLowerCase(Locale.ROOT))) out.add(p.getName());
        }
        return out;
    }
}
