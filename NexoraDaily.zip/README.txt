NexoraDaily  -  /daily rewards (Day 1 to Day 30)
=================================================

PLAYER COMMANDS
  /daily            open the reward window and claim today's reward
  /daily rewards    see all 30 days
  /daily claim      claim without the window (backup)

ADMIN COMMANDS (nexoradaily.admin)
  /daily reset (player)       start the player over at Day 1
  /daily set (player) (day)   choose the next day they will claim
  /daily reload               reload config.yml

HOW IT WORKS
  Claim Day 1 today, Day 2 tomorrow, and so on up to Day 30 (the OP jackpot).
  One claim per calendar day. After Day 30 the cycle starts again.
  Edit rewards, the timezone and messages in plugins/NexoraDaily/config.yml, then /daily reload.

BUILD THE JAR
  Computer:   install JDK 21 + Maven, run  mvn package   ->  target/NexoraDaily.jar
  GitHub:     upload this folder to a repo, open the Actions tab, download the "NexoraDaily" artifact.
  Install:    put NexoraDaily.jar in /plugins and restart.

REQUIRES  Paper 1.21.6 or newer (the dialog menu uses Paper's Dialog API).
